import { DEFAULT_TEMPO } from '../dsp'
import { FxGraph, MAX_BLOCK_FRAMES } from '../instrument'
import { type Patch, audioSources, sendTargets } from '../patch'
import type { AudioClip, SendLevels } from '../project'
import type { SampleLookup } from '../sample'
import { AudioClipLauncher, type AudioEvent, type LauncherStatus } from '../session'
import { fadeGain, readRegion, regionOf, repitchPosition } from './audio-clip-playback'
import { ChannelStrip } from './channel-strip'
import type { MixContext, MixTiming, PlayableTrack, ScheduledAction } from './playable-track'

/** A clip that stops (or is replaced) keeps sounding for this long, fading to silence, instead of cutting dead. */
const TAIL_SECONDS = 0.005

/** One clip as it is currently being read. */
interface Playing {
  clip: AudioClip
  startBeat: number
  /**
   * Read position in sample frames, used only by clips that ignore tempo (`warp: 'off'`).
   * Negative until the first read, when it is set to the start of the clip's region.
   */
  position: number
}

interface Tail {
  readonly voice: Playing
  framesLeft: number
  readonly total: number
}

/** Live, audio-thread counterpart of an audio Track: launcher plus the player that reads library samples. */
export class AudioTrackRuntime implements PlayableTrack {
  readonly strip: ChannelStrip
  clips: readonly (AudioClip | null)[]
  private readonly launcher = new AudioClipLauncher()
  private playing: Playing | null = null
  private tail: Tail | null = null
  private readonly tailFrames: number
  private fx: FxGraph
  private targets: string[]
  private sources: string[]
  /** The send knobs as pairs of (return track id, level), post-fader. */
  private sendList: ReadonlyArray<readonly [string, number]> = []
  /** The clip audio of the current stretch, before the insert graph. */
  private readonly scratch = new Float32Array(MAX_BLOCK_FRAMES)
  private tempo = DEFAULT_TEMPO

  constructor(
    private readonly trackId: string,
    fx: Patch,
    clips: readonly (AudioClip | null)[],
    volume: number,
    private readonly samples: SampleLookup,
    private readonly sampleRate: number,
  ) {
    this.clips = clips
    this.strip = new ChannelStrip(volume)
    this.tailFrames = Math.max(1, Math.round(TAIL_SECONDS * sampleRate))
    this.fx = new FxGraph(fx, sampleRate, samples)
    this.targets = sendTargets(fx)
    this.sources = audioSources(fx)
  }

  readouts(): Readonly<Record<string, number>> {
    return this.fx.readouts()
  }

  setTempo(bpm: number): void {
    this.tempo = bpm
    this.fx.setTempo(bpm)
  }

  setFx(fx: Patch): void {
    this.fx = new FxGraph(fx, this.sampleRate, this.samples, this.tempo)
    this.targets = sendTargets(fx)
    this.sources = audioSources(fx)
  }

  setSends(sends: SendLevels): void {
    this.sendList = Object.entries(sends)
  }

  audioSources(): string[] {
    return this.sources
  }

  sendTargets(): string[] {
    return [...new Set([...this.targets, ...this.sendList.map(([id]) => id)])]
  }

  clearAutomation(): void { this.fx.clearAutomation() }
  setAutomationCurve(nodeId: string, paramId: string, values: Float64Array): void { this.fx.setAutomationCurve(nodeId, paramId, values) }

  setParam(nodeId: string, paramId: string, value: number): void {
    this.fx.setParam(nodeId, paramId, value)
  }

  setSample(nodeId: string, sampleId: string | null): void {
    this.fx.setSample(nodeId, sampleId)
  }

  setClips(clips: readonly (AudioClip | null)[]): void {
    this.clips = clips
    this.launcher.syncClips(clips)
    // Edited settings (gain, trim, fades, loop…) apply to the clip that is sounding right now.
    if (this.playing) {
      const edited = clips.find((clip) => clip?.id === this.playing?.clip.id) ?? null
      this.playing = edited ? { ...this.playing, clip: edited } : null
    }
  }

  launchClip(clipId: string): void {
    const clip = this.clips.find((candidate) => candidate?.id === clipId)
    if (clip) this.launcher.launch(clip)
  }

  launchScene(scene: number): void {
    const clip = this.clips[scene]
    if (clip) this.launcher.launch(clip)
    else this.launcher.stop()
  }

  stopClip(): void {
    this.launcher.stop()
  }

  reset(): void {
    this.stoppedAt = undefined
    this.launcher.reset()
    this.fadeOutPlaying()
    this.playing = null
  }

  /** Exact next one-shot boundary, so automation also releases before any effect tail is mixed. */
  framesUntilEnd(timing: MixTiming): number {
    if (!this.playing || this.playing.clip.loop) return Infinity
    const { clip, startBeat, position } = this.playing
    const sample = this.samples.get(clip.sampleId)
    if (!sample) return Infinity
    if (clip.warp === 'repitch') return Math.max(0, Math.ceil((clip.lengthBeats - (timing.beat - startBeat)) / timing.beatsPerSample - 1e-8))
    const region = regionOf(clip.start, clip.end, sample.data.length)
    const left = region.endPos - (position < 0 ? region.startPos : position)
    return Math.max(0, Math.ceil(left / (sample.sampleRate / this.sampleRate) - 1e-8))
  }
  private stoppedAt: number | undefined
  finishClip(beat: number): void { this.playing = null; this.stoppedAt = beat }

  /** What is sounding (not just queued, and not a fading tail), so a finished one-shot stops showing as playing. */
  status(): LauncherStatus {
    return {
      ...(this.stoppedAt !== undefined && { stopBeat: this.stoppedAt }),
      playingClipId: this.playing?.clip.id ?? null,
      startBeat: this.playing?.startBeat ?? null,
      queued: this.launcher.queuedStatus(),
    }
  }

  tapSources(): string[] {
    return []
  }

  schedule(from: number, to: number): ScheduledAction[] {
    return this.launcher
      .collectEvents(from, to)
      .map((event) => ({ beat: event.beat, run: () => this.apply(event) }))
  }

  private apply(event: AudioEvent): void {
    this.fadeOutPlaying()
    this.stoppedAt = event.kind === 'stop' ? event.beat : undefined
    this.playing = event.kind === 'start' ? { clip: event.clip, startBeat: event.beat, position: -1 } : null
  }

  /** Hands what is sounding over to a short fade-out, so whatever replaces it (or silence) starts without a click. */
  private fadeOutPlaying(): void {
    if (this.playing) this.tail = { voice: this.playing, framesLeft: this.tailFrames, total: this.tailFrames }
  }

  /** The clip audio goes through the insert graph (which keeps ringing after the clip ends), then the fader. */
  mixInto(left: Float32Array, right: Float32Array, offset: number, frames: number, { timing, sends, taps }: MixContext): void {
    this.scratch.fill(0, 0, frames)
    if (this.tail) {
      const alive = this.mixVoice(this.tail.voice, frames, timing, this.tail)
      this.tail.framesLeft -= frames
      if (!alive || this.tail.framesLeft <= 0) this.tail = null
    }
    const remaining = this.framesUntilEnd(timing)
    if (this.playing && !this.mixVoice(this.playing, frames, timing)) this.finishClip(timing.beat + Math.min(frames, remaining) * timing.beatsPerSample)

    taps.write(this.trackId, 0, this.scratch, frames)
    const gate = this.strip.sendsTo(sends)
    const signal = this.fx.process(this.scratch, frames, { sends: gate, taps })
    taps.write(this.trackId, 1, signal, frames)
    this.strip.mixInto(left, right, offset, frames, signal)
    for (const [returnId, level] of this.sendList) this.strip.send(gate, returnId, signal, level, frames)
  }

  /** Adds `frames` of `voice` to the scratch buffer. Returns false once the clip has finished (a non-looping pass ended). */
  private mixVoice(voice: Playing, frames: number, timing: MixTiming, tail?: Tail): boolean {
    const sample = this.samples.get(voice.clip.sampleId)
    if (!sample) return true // a sample that hasn't arrived yet just plays silence, then joins in phase

    const { clip } = voice
    const { data } = sample
    const region = regionOf(clip.start, clip.end, data.length)
    const regionLength = region.endPos - region.startPos
    const fadeInFrames = clip.fadeIn * sample.sampleRate
    const fadeOutFrames = clip.fadeOut * sample.sampleRate
    const gain = clip.gain
    const nativeSpeed = sample.sampleRate / this.sampleRate
    if (voice.position < 0) voice.position = region.startPos

    for (let i = 0; i < frames; i++) {
      let position: number | null
      if (clip.warp === 'repitch') {
        position = repitchPosition(
          timing.beat + i * timing.beatsPerSample - voice.startBeat,
          clip.lengthBeats,
          clip.loop,
          region,
        )
      } else {
        position = voice.position
        if (position >= region.endPos) {
          position = clip.loop ? region.startPos + ((position - region.startPos) % regionLength) : null
        }
        if (position !== null) voice.position = position + nativeSpeed
      }
      if (position === null) return false

      let level = gain * fadeGain(position, region, fadeInFrames, fadeOutFrames)
      if (tail) {
        const remaining = tail.framesLeft - i
        if (remaining <= 0) return false
        level *= remaining / tail.total
      }
      const value = readRegion(data, position, region, clip.loop) * level
      this.scratch[i] = (this.scratch[i] ?? 0) + value
    }
    return true
  }
}
