import { eventInScope, type NoteScope, type NoteEvent } from '../session'

/** Beat comparisons share automation's tolerance so a rounded block end cannot consume the next sample's event. */
export const NOTE_BEAT_EPSILON = 1e-10

const KIND_PRIORITY: Record<NoteEvent['kind'], number> = { allOff: 0, noteOff: 1, noteOn: 2 }

/** Time order, and at the same beat: everything off first, then note-offs, then note-ons. */
export const compareEvents = (a: NoteEvent, b: NoteEvent): number =>
  a.beat - b.beat || KIND_PRIORITY[a.kind] - KIND_PRIORITY[b.kind]

/** Events scheduled for later, released as the clock reaches them. */
export class EventQueue {
  private events: NoteEvent[] = []

  add(event: NoteEvent): void {
    this.events.push(event)
  }

  /** Removes and returns the events due before `to` (in order). */
  takeBefore(to: number): NoteEvent[] {
    const due = this.events.filter((event) => event.beat < to - NOTE_BEAT_EPSILON)
    if (due.length > 0) this.events = this.events.filter((event) => event.beat >= to - NOTE_BEAT_EPSILON)
    return due.sort(compareEvents)
  }

  /** Removes everything and returns the note-offs that were still pending (so nothing stays on). */
  clear(): NoteEvent[] {
    const offs = this.events.filter((event) => event.kind === 'noteOff')
    this.events = []
    return offs
  }

  cancel(scope?: NoteScope): void {
    this.events = this.events.filter((event) => !eventInScope(event, scope))
  }

  get size(): number {
    return this.events.length
  }
}
