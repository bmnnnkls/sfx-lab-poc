import { readFileSync } from 'node:fs'
import type { InstrumentTrack } from '../project'
import { describe, expect, it } from 'vitest'
import { addNode, createNode, describeNode, noteGraphFrom } from '../patch'
import { type Project, createDemoProject, createReturnTrack, editPatchAt, groupNodesAsModule } from '../project'
import { parseProject, serializeProject } from './project-file'

const parseOk = (text: string) => {
  const result = parseProject(text)
  if (!result.ok) throw new Error(result.error)
  return result
}

const envelope = (project: unknown, version = 1) =>
  JSON.stringify({ format: 'sfx-lab-project', version, project })

const project = (overrides: Record<string, unknown>) => ({
  name: 'T',
  tempo: 120,
  sceneCount: 2,
  tracks: [],
  ...overrides,
})

describe('project file round trip', () => {
  it('restores the demo project exactly, compact or pretty', () => {
    const demo = createDemoProject()
    for (const space of [undefined, 2]) {
      const result = parseOk(serializeProject(demo, space))
      expect(result.project).toEqual(demo)
      expect(result.warnings).toEqual([])
    }
  })

  it('reads the committed v1 fixture without warnings', () => {
    const text = readFileSync(new URL('./fixtures/v1-minimal.sfxlab.json', import.meta.url), 'utf8')
    const { project: loaded, warnings } = parseOk(text)

    expect(warnings).toEqual([])
    expect(loaded.name).toBe('Fixture v1')
    expect((loaded.tracks[0] as InstrumentTrack).patch.connections.map((c) => c.id)).toEqual(['w1', 'w2'])
    expect((loaded.tracks[0] as InstrumentTrack).clips[0]?.notes).toHaveLength(2)
    expect((loaded.tracks[0] as InstrumentTrack).clips[1]).toBeNull()
  })

  it('gives files saved before polyphony the default voice count, silently', () => {
    const text = readFileSync(new URL('./fixtures/v1-minimal.sfxlab.json', import.meta.url), 'utf8')
    const { project: loaded, warnings } = parseOk(text)

    expect((loaded.tracks[0] as InstrumentTrack).voices).toBe(8)
    expect(warnings).toEqual([])
  })

  it('clamps an out-of-range voice count', () => {
    const raw = project({ tracks: [{ id: 't', name: 'T', voices: 500, patch: {}, clips: [] }] })
    expect((parseOk(envelope(raw)).project.tracks[0] as InstrumentTrack).voices).toBe(16)
  })
})

describe('insert graphs in files', () => {
  const tracks = (extra: Record<string, unknown>) =>
    project({ tracks: [{ id: 't', name: 'T', patch: {}, clips: [], ...extra }, { id: 'a', name: 'A', kind: 'audio', clips: [], ...extra }] })
  const types = (patch: { nodes: readonly { type: string }[] }) => patch.nodes.map((node) => node.type)

  it('gives files saved before insert graphs the default graph on every track, silently', () => {
    const { project: loaded, warnings } = parseOk(envelope(tracks({})))
    for (const track of loaded.tracks) expect(types(track.fx)).toEqual(['trackIn', 'trackOut'])
    expect(loaded.tracks[0]!.fx.connections).toHaveLength(1)
    expect(warnings).toEqual([])
  })

  it('round-trips a graph with effects, on both kinds of track', () => {
    const base = createDemoProject()
    const withFx = {
      ...base,
      tracks: base.tracks.map((track) => ({
        ...track,
        fx: noteGraphFrom(
          [{ id: `i${track.id}`, type: 'trackIn' }, { id: `r${track.id}`, type: 'reverb', params: { mix: 0.5 } }, { id: `o${track.id}`, type: 'trackOut' }],
          [`i${track.id}.out>r${track.id}.in`, `r${track.id}.out>o${track.id}.in`],
        ),
      })),
    }
    const result = parseOk(serializeProject(withFx))
    expect(result.project).toEqual(withFx)
    expect(result.warnings).toEqual([])
  })

  it('drops note nodes, unknown nodes and bad wires from a hand-edited graph, and says so', () => {
    const fx = {
      nodes: [
        { id: 'i', type: 'trackIn', x: 0, y: 0, params: {} },
        { id: 'n', type: 'transpose', x: 0, y: 0, params: {} }, // a note node does not belong in sound
        { id: 'z', type: 'nonsense', x: 0, y: 0, params: {} },
        { id: 'f', type: 'filter', x: 0, y: 0, params: { cutoff: 1e9 } },
        { id: 'o', type: 'trackOut', x: 0, y: 0, params: {} },
      ],
      connections: [
        { id: 'w1', from: { node: 'i', port: 'out' }, to: { node: 'f', port: 'in' } },
        { id: 'w2', from: { node: 'f', port: 'out' }, to: { node: 'o', port: 'in' } },
        { id: 'w3', from: { node: 'o', port: 'in' }, to: { node: 'i', port: 'out' } }, // backwards
      ],
    }
    const { project: loaded, warnings } = parseOk(envelope(tracks({ fx })))
    expect(types(loaded.tracks[0]!.fx)).toEqual(['trackIn', 'filter', 'trackOut'])
    expect(loaded.tracks[0]!.fx.nodes[1]!.params.cutoff).toBe(20000)
    expect(warnings.join('\n')).toMatch(/do not mix/)
  })

  it('falls back to the default graph when the stored one is not an object', () => {
    for (const fx of ['text', 5, [], null]) {
      const { project: loaded } = parseOk(envelope(tracks({ fx })))
      expect(types(loaded.tracks[1]!.fx)).toEqual(['trackIn', 'trackOut'])
    }
  })
})

describe('stereo in files', () => {
  const fx = (nodes: unknown[], connections: unknown[] = []) =>
    parseOk(envelope(project({ tracks: [{ id: 't', name: 'T', patch: {}, clips: [], fx: { nodes, connections } }] }))).project.tracks[0]!.fx
  const node = (id: string, type: string, extra: Record<string, unknown> = {}) => ({ id, type, x: 0, y: 0, params: {}, ...extra })

  it('keeps the stereo switch on nodes that can run in stereo, with the wires that need it', () => {
    const patch = fx(
      [node('i', 'trackIn'), node('p', 'pan'), node('f', 'filter', { stereo: true }), node('o', 'trackOut')],
      [
        { id: 'a', from: { node: 'i', port: 'out' }, to: { node: 'p', port: 'in' } },
        { id: 'b', from: { node: 'p', port: 'out' }, to: { node: 'f', port: 'in' } },
        { id: 'c', from: { node: 'f', port: 'out' }, to: { node: 'o', port: 'in' } },
      ],
    )
    expect(patch.nodes.find((n) => n.id === 'f')?.stereo).toBe(true)
    expect(patch.connections.map((c) => c.id)).toEqual(['a', 'b', 'c'])
  })

  it('drops a stereo wire into a mono input, and ignores the switch on a node that cannot go stereo', () => {
    const patch = fx(
      [node('i', 'trackIn'), node('p', 'pan', { stereo: true }), node('f', 'filter'), node('o', 'trackOut')],
      [
        { id: 'a', from: { node: 'i', port: 'out' }, to: { node: 'p', port: 'in' } },
        { id: 'b', from: { node: 'p', port: 'out' }, to: { node: 'f', port: 'in' } }, // stereo -> mono: not allowed
      ],
    )
    expect(patch.nodes.find((n) => n.id === 'p')).not.toHaveProperty('stereo')
    expect(patch.connections.map((c) => c.id)).toEqual(['a'])
  })

  it('round-trips a stereo graph', () => {
    const base = createDemoProject()
    const stereoFx = noteGraphFrom(
      [{ id: 'i', type: 'trackIn' }, { id: 'p', type: 'pan', params: { pan: 0.4 } }, { id: 'r', type: 'stereoReverb' }, { id: 'o', type: 'trackOut' }],
      ['i.out>p.in', 'p.out>r.in', 'r.out>o.in'],
    )
    const withFx = { ...base, tracks: base.tracks.map((track) => ({ ...track, fx: stereoFx })) }
    const result = parseOk(serializeProject(withFx))
    expect(result.project).toEqual(withFx)
    expect(result.warnings).toEqual([])
  })
})

describe('return tracks and sends in files', () => {
  const node = (id: string, type: string, extra: Record<string, unknown> = {}) => ({ id, type, x: 0, y: 0, params: {}, ...extra })
  const wire = (id: string, from: string, to: string, fromPort = 'out', toPort = 'in') => ({ id, from: { node: from, port: fromPort }, to: { node: to, port: toPort } })
  /** A graph that takes the track's sound straight through and also sends it to `target`. */
  const sending = (target: unknown) => ({
    nodes: [node('i', 'trackIn'), node('s', 'send', { trackId: target }), node('o', 'trackOut')],
    connections: [wire('a', 'i', 'o'), wire('b', 'i', 's')],
  })
  const returnTrack = (id: string, extra: Record<string, unknown> = {}) => ({ id, name: id, kind: 'return', volume: 0.6, ...extra })
  const instrument = (id: string, fx: unknown) => ({ id, name: id, patch: {}, clips: [], fx })
  const load = (tracks: unknown[]) => parseOk(envelope(project({ tracks })))
  const target = (loaded: ReturnType<typeof load>, track: string, node = 's') => loaded.project.tracks.find((t) => t.id === track)!.fx.nodes.find((n) => n.id === node)?.trackId

  it('round-trips a project with a return track and a Send to it', () => {
    const base = createDemoProject()
    const ret = createReturnTrack('Return A')
    const bass = base.tracks[0]!
    const withSend = {
      ...base,
      tracks: [{ ...bass, fx: noteGraphFrom([{ id: 'i', type: 'trackIn' }, { id: 's', type: 'send', trackId: ret.id, params: { amount: 0.4 } }, { id: 'o', type: 'trackOut' }], ['i.out>o.in', 'i.out>s.in']) }, ...base.tracks.slice(1), ret],
    }
    const result = parseOk(serializeProject(withSend))
    expect(result.project).toEqual(withSend)
    expect(result.warnings).toEqual([])
  })

  it('loads a return track without effects with the default return graph', () => {
    const loaded = load([returnTrack('r')])
    const track = loaded.project.tracks[0]!
    expect(track.kind).toBe('return')
    expect(track.volume).toBe(0.6)
    expect(track.fx.nodes.map((n) => n.type)).toEqual(['returnIn', 'trackOut'])
    expect(track).not.toHaveProperty('clips')
  })

  it('keeps a valid Send and ignores clips a return track should not have', () => {
    const loaded = load([instrument('t', sending('r')), returnTrack('r', { clips: [{ id: 'c' }] })])
    expect(target(loaded, 't')).toBe('r')
    expect(loaded.project.tracks[1]).not.toHaveProperty('clips')
    expect(loaded.warnings).toEqual([])
  })

  it('drops a Send to a missing track, to an instrument track, and to its own track, with a warning each', () => {
    const loaded = load([instrument('t', sending('ghost')), instrument('u', sending('t')), returnTrack('r', { fx: sending('r') })])
    expect(target(loaded, 't')).toBeUndefined()
    expect(target(loaded, 'u')).toBeUndefined()
    expect(target(loaded, 'r')).toBeUndefined()
    expect(loaded.warnings.filter((w) => /Send/.test(w))).toHaveLength(3)
  })

  it('drops the Send that would close a loop between two returns, keeping the other', () => {
    const loaded = load([returnTrack('r1', { fx: sending('r2') }), returnTrack('r2', { fx: sending('r1') })])
    expect([target(loaded, 'r1'), target(loaded, 'r2')].filter((t) => t !== undefined)).toHaveLength(1)
    expect(loaded.warnings.join('\n')).toMatch(/depend on each other/)
  })

  it('keeps send knob levels for return tracks, clamped, and drops the rest', () => {
    const loaded = load([
      { ...instrument('t', undefined), sends: { r: 0.5, r2: 7, ghost: 0.5, t: 0.5, zero: 0 } },
      { ...instrument('u', undefined), sends: { r: 'loud' } },
      { ...instrument('v', undefined), sends: 'nope' },
      returnTrack('r'),
      returnTrack('r2', { sends: { r: 1 } }),
    ])
    const sends = (id: string) => {
      const track = loaded.project.tracks.find((t) => t.id === id)!
      return track.kind === 'return' ? undefined : track.sends
    }
    expect(sends('t')).toEqual({ r: 0.5, r2: 1 })
    expect(sends('u')).toEqual({})
    expect(sends('v')).toEqual({})
    expect(sends('r2')).toBeUndefined() // a return track has no knobs
    expect(loaded.warnings.join('\n')).toMatch(/send level/)
  })

  it('round-trips send knob levels', () => {
    const base = createDemoProject()
    const ret = createReturnTrack('Return A')
    const withSends = { ...base, tracks: [{ ...base.tracks[0]!, sends: { [ret.id]: 0.25 } }, ...base.tracks.slice(1), ret] }
    const result = parseOk(serializeProject(withSends as Project))
    expect(result.project).toEqual(withSends)
  })

  it('keeps a valid Track audio input; drops one that points at a missing track, at its own track, or at a loop', () => {
    const taking = (target: unknown) => ({
      nodes: [node('i', 'trackIn'), node('a', 'trackAudio', { trackId: target }), node('o', 'trackOut')],
      connections: [wire('w', 'a', 'o')],
    })
    const loaded = load([instrument('t', taking('u')), instrument('u', taking('ghost')), instrument('v', taking('v')), instrument('p', taking('q')), instrument('q', taking('p'))])
    expect(target(loaded, 't', 'a')).toBe('u')
    expect(target(loaded, 'u', 'a')).toBeUndefined()
    expect(target(loaded, 'v', 'a')).toBeUndefined()
    expect([target(loaded, 'p', 'a'), target(loaded, 'q', 'a')].filter((t) => t !== undefined)).toHaveLength(1)
    expect(loaded.warnings.join('\n')).toMatch(/audio from track/)
  })

  it('drops the Send, the Track audio input or the knob that completes a loop between a track and a return', () => {
    const takingFrom = (source: string) => ({ nodes: [node('i', 'trackIn'), node('a', 'trackAudio', { trackId: source }), node('o', 'trackOut')], connections: [wire('w', 'a', 'o')] })
    // t sends to r and also takes audio from r: one of the two must go
    const byNode = load([instrument('t', { nodes: [...sending('r').nodes, node('a', 'trackAudio', { trackId: 'r' })], connections: sending('r').connections }), returnTrack('r')])
    const t = byNode.project.tracks.find((x) => x.id === 't')!
    expect([t.fx.nodes.find((n) => n.id === 's')?.trackId, t.fx.nodes.find((n) => n.id === 'a')?.trackId].filter((x) => x !== undefined)).toHaveLength(1)
    // t takes audio from r and has a knob for r
    const byKnob = load([{ ...instrument('t', takingFrom('r')), sends: { r: 0.5 } }, returnTrack('r')])
    const kept = byKnob.project.tracks.find((x) => x.id === 't')!
    const knob = kept.kind !== 'return' && 'r' in kept.sends
    const input = kept.fx.nodes.find((n) => n.id === 'a')?.trackId !== undefined
    expect(knob && input).toBe(false) // one of the two had to go
    expect(knob || input).toBe(true) // and only one
    expect(byKnob.warnings.join('\n')).toMatch(/depend on each other/)
  })

  it('survives a garbage trackId on a Send', () => {
    for (const bad of [5, null, {}, [], '']) {
      expect(() => load([instrument('t', sending(bad)), returnTrack('r')])).not.toThrow()
      expect(target(load([instrument('t', sending(bad)), returnTrack('r')]), 't')).toBeUndefined()
    }
  })

  it('still repairs notes taken from other tracks, which share the repair', () => {
    const tapping = (source: string) => ({ ...instrument('t', undefined), noteGraph: { nodes: [node('n', 'trackNotes', { trackId: source }), node('o', 'noteOut')], connections: [wire('w', 'n', 'o')] } })
    const loaded = load([tapping('t')])
    expect((loaded.project.tracks[0] as InstrumentTrack).noteGraph.nodes.find((n) => n.id === 'n')?.trackId).toBeUndefined()
    expect(loaded.warnings.join('\n')).toMatch(/notes from track/)
  })
})

describe('the master bus in files', () => {
  const node = (id: string, type: string, extra: Record<string, unknown> = {}) => ({ id, type, x: 0, y: 0, params: {}, ...extra })
  const types = (fx: { nodes: readonly { type: string }[] }) => fx.nodes.map((n) => n.type)

  it('gives files saved before the master bus the default graph, silently', () => {
    const { project: loaded, warnings } = parseOk(envelope(project({})))
    expect(types(loaded.master.fx)).toEqual(['masterIn', 'trackOut'])
    expect(loaded.master.fx.connections).toHaveLength(1)
    expect(warnings).toEqual([])
  })

  it('round-trips a master graph with effects', () => {
    const base = createDemoProject()
    const withMaster = {
      ...base,
      master: { fx: noteGraphFrom([{ id: 'i', type: 'masterIn' }, { id: 'w', type: 'width', params: { width: 1.5 } }, { id: 'r', type: 'stereoReverb' }, { id: 'o', type: 'trackOut' }], ['i.out>w.in', 'w.out>r.in', 'r.out>o.in']) },
    }
    const result = parseOk(serializeProject(withMaster))
    expect(result.project).toEqual(withMaster)
    expect(result.warnings).toEqual([])
  })

  it('cleans a hand-edited master graph like any other, and falls back to the default for garbage', () => {
    const fx = {
      nodes: [node('i', 'masterIn'), node('n', 'transpose'), node('f', 'filter', { params: { cutoff: 1e9 } }), node('o', 'trackOut')],
      connections: [
        { id: 'a', from: { node: 'i', port: 'out' }, to: { node: 'f', port: 'in' } }, // stereo into a mono filter: not allowed
        { id: 'b', from: { node: 'f', port: 'out' }, to: { node: 'o', port: 'in' } },
      ],
    }
    const { project: loaded, warnings } = parseOk(envelope(project({ master: { fx } })))
    expect(types(loaded.master.fx)).toEqual(['masterIn', 'filter', 'trackOut'])
    expect(loaded.master.fx.nodes[1]!.params.cutoff).toBe(20000)
    expect(loaded.master.fx.connections.map((c) => c.id)).toEqual(['b'])
    expect(warnings.join('\n')).toMatch(/Master effects/)

    for (const master of ['x', 5, null, [], { fx: 'y' }]) {
      expect(types(parseOk(envelope(project({ master }))).project.master.fx)).toEqual(['masterIn', 'trackOut'])
    }
  })
})

describe('rejecting bad files', () => {
  it.each([
    ['not json', 'nope{', /not valid JSON/],
    ['a different JSON file', '{"hello":1}', /not an SFX Lab project/],
    ['a missing version', JSON.stringify({ format: 'sfx-lab-project', project: {} }), /version/],
    ['a newer version', envelope({}, 99), /newer version/],
    ['no project payload', envelope(null), /no project data/],
  ])('%s', (_label, text, message) => {
    const result = parseProject(text)
    expect(result.ok).toBe(false)
    if (!result.ok) expect(result.error).toMatch(message)
  })
})

describe('sanitizing', () => {
  const track = (patch: unknown, clips: unknown[] = []) => ({ id: 't', name: 'T', patch, clips })

  it('drops unknown nodes, dangling wires and cycles, and says so', () => {
    const patch = {
      nodes: [
        { id: 'a', type: 'gain', x: 0, y: 0, params: {} },
        { id: 'b', type: 'gain', x: 0, y: 0, params: {} },
        { id: 'c', type: 'does-not-exist', x: 0, y: 0, params: {} },
      ],
      connections: [
        { id: 'w1', from: { node: 'a', port: 'out' }, to: { node: 'b', port: 'in' } },
        { id: 'w2', from: { node: 'b', port: 'out' }, to: { node: 'a', port: 'in' } }, // cycle
        { id: 'w3', from: { node: 'a', port: 'out' }, to: { node: 'zzz', port: 'in' } }, // dangling
      ],
    }
    const { project: loaded, warnings } = parseOk(envelope(project({ tracks: [track(patch)] })))

    expect((loaded.tracks[0] as InstrumentTrack).patch.nodes.map((n) => n.id)).toEqual(['a', 'b'])
    expect((loaded.tracks[0] as InstrumentTrack).patch.connections).toHaveLength(1)
    expect(warnings.join('\n')).toMatch(/unknown node type "does-not-exist"/)
    expect(warnings.join('\n')).toMatch(/dropped 2 invalid connection/)
  })

  it('clamps params and numbers to valid ranges', () => {
    const patch = {
      nodes: [{ id: 'f', type: 'filter', x: 'oops', y: 5, params: { cutoff: 1e9, resonance: 'x' } }],
      connections: [],
    }
    const clip = { id: 'c', name: 'C', lengthBeats: 4, notes: [
      { pitch: 500, start: 0, duration: -3, velocity: 7 },
      { pitch: 60, start: 99, duration: 1, velocity: 1 }, // beyond clip end
      'garbage',
    ] }
    const raw = project({ tempo: 9999, tracks: [{ ...track(patch, [clip]), volume: 5 }] })
    const { project: loaded, warnings } = parseOk(envelope(raw))
    const node = (loaded.tracks[0] as InstrumentTrack).patch.nodes[0]!

    expect(loaded.tempo).toBe(240)
    expect(loaded.tracks[0]?.volume).toBe(1)
    expect(node.x).toBe(0)
    expect(node.params).toMatchObject({ cutoff: 20000, resonance: 0.707 })
    expect((loaded.tracks[0] as InstrumentTrack).clips[0]?.notes).toEqual([
      { id: expect.stringMatching(/^note_/), pitch: 127, start: 0, duration: 1 / 16, velocity: 1 },
    ])
    expect(warnings.join('\n')).toMatch(/dropped 2 invalid note/)
  })

  it('makes ids unique and fits clip slots to the scene count', () => {
    const clip = { id: 'same', name: 'C', lengthBeats: 4, notes: [] }
    const raw = project({
      sceneCount: 3,
      tracks: [
        { ...track({}, [clip, clip, clip, clip]), id: 'dup' },
        { ...track({}, []), id: 'dup' },
      ],
    })
    const { project: loaded } = parseOk(envelope(raw))

    expect(new Set(loaded.tracks.map((t) => t.id)).size).toBe(2)
    expect((loaded.tracks[0] as InstrumentTrack).clips).toHaveLength(3)
    expect(new Set((loaded.tracks[0] as InstrumentTrack).clips.map((c) => c?.id)).size).toBe(3)
    expect((loaded.tracks[1] as InstrumentTrack).clips).toEqual([null, null, null])
  })

  it('survives garbage inside an otherwise valid envelope', () => {
    const raw = project({ tracks: [null, 7, 'x', { patch: 5, clips: 'no' }] })
    const { project: loaded } = parseOk(envelope(raw))

    expect(loaded.tracks).toHaveLength(1)
    expect((loaded.tracks[0] as InstrumentTrack).patch).toEqual({ nodes: [], connections: [] })
  })
})

describe('samples in files', () => {
  const id = 'c'.repeat(64)
  const sampleEntry = { id, name: 'Kick', extension: 'wav', durationSeconds: 1.5, sampleRate: 44100, channels: 2, bytes: 5000 }
  const samplerPatch = (sampleId: unknown) => ({
    nodes: [{ id: 's', type: 'sampler', x: 0, y: 0, params: {}, sampleId }],
    connections: [],
  })
  const track = (patch: unknown) => ({ id: 't', name: 'T', patch, clips: [] })

  it('round-trips the library and sampler references', () => {
    const raw = project({ samples: [sampleEntry], tracks: [track(samplerPatch(id))] })
    const { project: loaded, warnings } = parseOk(envelope(raw))

    expect(warnings).toEqual([])
    expect(loaded.samples).toEqual([sampleEntry])
    expect((loaded.tracks[0] as InstrumentTrack).patch.nodes[0]?.sampleId).toBe(id)
    expect(parseOk(serializeProject(loaded)).project).toEqual(loaded)
  })

  it('drops invalid library entries and says so', () => {
    const raw = project({
      samples: [sampleEntry, sampleEntry, { id: 'not-a-hash', name: 'x' }, 'junk', { ...sampleEntry, id: 'd'.repeat(64), extension: '../etc', sampleRate: 1e9, channels: 99 }],
    })
    const { project: loaded, warnings } = parseOk(envelope(raw))

    expect(loaded.samples.map((s) => s.id)).toEqual([id, 'd'.repeat(64)])
    expect(loaded.samples[1]).toMatchObject({ extension: 'bin', sampleRate: 192000, channels: 8 })
    expect(warnings.join('\n')).toMatch(/Skipped 3 invalid sample entries/)
  })

  it('drops a sampler reference to a sample that is not in the library', () => {
    const raw = project({ samples: [], tracks: [track(samplerPatch(id))] })
    const { project: loaded, warnings } = parseOk(envelope(raw))

    expect((loaded.tracks[0] as InstrumentTrack).patch.nodes[0]?.sampleId).toBeUndefined()
    expect(warnings.join('\n')).toMatch(/pointed at a sample that is not in the project/)
  })

  it('loads older files that have no sample library', () => {
    expect(parseOk(envelope(project({}))).project.samples).toEqual([])
  })
})

describe('note ids in files', () => {
  const clipWith = (notes: unknown[]) => ({
    id: 'c', name: 'C', lengthBeats: 4, notes,
  })
  const load = (notes: unknown[]) =>
    (parseOk(envelope(project({ tracks: [{ id: 't', name: 'T', patch: {}, clips: [clipWith(notes)] }] }))).project.tracks[0] as InstrumentTrack).clips[0]!.notes

  it('keeps saved ids and gives older files (no ids) fresh unique ones, without warnings', () => {
    const kept = load([{ id: 'mine', pitch: 60, start: 0, duration: 1, velocity: 1 }])
    expect(kept[0]!.id).toBe('mine')

    const old = load([
      { pitch: 60, start: 0, duration: 1, velocity: 1 },
      { pitch: 62, start: 1, duration: 1, velocity: 1 },
    ])
    expect(new Set(old.map((n) => n.id)).size).toBe(2)
    expect(old.every((n) => n.id.startsWith('note_'))).toBe(true)
  })

  it('re-ids duplicate note ids so selections stay unambiguous', () => {
    const notes = load([
      { id: 'same', pitch: 60, start: 0, duration: 1, velocity: 1 },
      { id: 'same', pitch: 62, start: 1, duration: 1, velocity: 1 },
    ])
    expect(new Set(notes.map((n) => n.id)).size).toBe(2)
  })
})

describe('audio tracks in files', () => {
  const id = 'e'.repeat(64)
  const sampleEntry = { id, name: 'Loop', extension: 'wav', durationSeconds: 2, sampleRate: 44100, channels: 1, bytes: 10 }
  const audioTrack = (clips: unknown[], extra: Record<string, unknown> = {}) => ({
    kind: 'audio', id: 'at', name: 'Audio', volume: 0.7, clips, ...extra,
  })
  const clip = (overrides: Record<string, unknown> = {}) => ({
    id: 'ac', name: 'Loop', sampleId: id, lengthBeats: 4, loop: true, warp: 'repitch', gain: 1, ...overrides,
  })

  it('round-trips an audio track with its clip', () => {
    const raw = project({ samples: [sampleEntry], tracks: [audioTrack([clip(), null])] })
    const { project: loaded, warnings } = parseOk(envelope(raw))

    expect(warnings).toEqual([])
    expect(loaded.tracks[0]).toMatchObject({ kind: 'audio', id: 'at', volume: 0.7 })
    expect(parseOk(serializeProject(loaded)).project).toEqual(loaded)
  })

  it('treats a track with no kind (older files) as an instrument', () => {
    const loaded = parseOk(envelope(project({ tracks: [{ id: 't', name: 'T', patch: {}, clips: [] }] }))).project
    expect(loaded.tracks[0]?.kind).toBe('instrument')
  })

  it('drops an audio clip whose sample is not in the project, with a warning', () => {
    const raw = project({ samples: [], tracks: [audioTrack([clip()])] })
    const { project: loaded, warnings } = parseOk(envelope(raw))

    expect((loaded.tracks[0] as unknown as { clips: unknown[] }).clips).toEqual([null, null])
    expect(warnings.join('\n')).toMatch(/audio clip whose sample is not in the project/)
  })

  it('repairs out-of-range settings and unknown warp modes', () => {
    const raw = project({
      samples: [sampleEntry],
      tracks: [audioTrack([clip({ gain: 50, lengthBeats: 'x', warp: 'wobble', loop: 'yes' })])],
    })
    const loaded = parseOk(envelope(raw)).project.tracks[0] as unknown as { clips: Array<Record<string, unknown>> }

    expect(loaded.clips[0]).toMatchObject({ gain: 2, lengthBeats: 4, warp: 'repitch', loop: true })
  })

  it('gives clips unique ids and fits the slots to the scene count', () => {
    const raw = project({ sceneCount: 3, samples: [sampleEntry], tracks: [audioTrack([clip(), clip(), clip(), clip()])] })
    const loaded = parseOk(envelope(raw)).project.tracks[0] as unknown as { clips: Array<{ id: string } | null> }

    expect(loaded.clips).toHaveLength(3)
    expect(new Set(loaded.clips.map((c) => c?.id)).size).toBe(3)
  })

  it('gives clips saved before trim and fades the whole sample and no fades, as they always had', () => {
    const raw = project({ samples: [sampleEntry], tracks: [audioTrack([clip()])] })
    const loaded = parseOk(envelope(raw)).project.tracks[0] as unknown as { clips: Array<Record<string, unknown>> }
    expect(loaded.clips[0]).toMatchObject({ start: 0, end: 1, fadeIn: 0, fadeOut: 0 })
  })

  it('repairs a nonsensical trim region and out-of-range fades', () => {
    const raw = project({ samples: [sampleEntry], tracks: [audioTrack([clip({ start: 0.9, end: 0.1, fadeIn: -3, fadeOut: 'x' })])] })
    const loaded = parseOk(envelope(raw)).project.tracks[0] as unknown as { clips: Array<{ start: number; end: number; fadeIn: number; fadeOut: number }> }
    const c = loaded.clips[0]!
    expect(c.start).toBe(0.9)
    expect(c.end).toBeGreaterThan(c.start)
    expect(c.fadeIn).toBe(0)
    expect(c.fadeOut).toBe(0)
  })

  it('round-trips a trimmed, faded clip', () => {
    const raw = project({ samples: [sampleEntry], tracks: [audioTrack([clip({ start: 0.25, end: 0.75, fadeIn: 0.05, fadeOut: 0.1 })])] })
    const { project: loaded } = parseOk(envelope(raw))
    expect(parseOk(serializeProject(loaded)).project).toEqual(loaded)
    expect((loaded.tracks[0] as unknown as { clips: Array<Record<string, unknown>> }).clips[0]).toMatchObject({ start: 0.25, end: 0.75, fadeIn: 0.05, fadeOut: 0.1 })
  })
})

describe('modules in files', () => {
  const grouped = () => {
    const demo = createDemoProject()
    const bass = demo.tracks[0] as InstrumentTrack
    const ids = ['oscillator', 'filter'].map((type) => bass.patch.nodes.find((node) => node.type === type)!.id)
    return groupNodesAsModule(demo, { trackId: bass.id }, ids, 'Core')
  }

  it('round-trips modules and their uses exactly', () => {
    const original = grouped()
    const result = parseOk(serializeProject(original, 2))
    expect(result.project).toEqual(original)
    expect(result.warnings).toEqual([])
  })

  it('files from before modules existed load with an empty library', () => {
    const result = parseOk(envelope(project({ tracks: [] })))
    expect(result.project.modules).toEqual([])
  })

  it('drops uses of modules that are missing from the file, with a warning', () => {
    const original = grouped()
    const raw = JSON.parse(serializeProject(original))
    raw.project.modules = []
    const result = parseOk(JSON.stringify(raw))
    const track = result.project.tracks[0] as InstrumentTrack
    expect(track.patch.nodes.some((node) => node.type === 'module')).toBe(false)
    expect(result.warnings.join(' ')).toMatch(/module that is not in the project/)
  })

  it('drops ports and knobs that point at nothing', () => {
    const raw = JSON.parse(serializeProject(grouped()))
    raw.project.modules[0].inputs.push({ id: 'x', label: 'Ghost', inner: { node: 'nope', port: 'in' } })
    raw.project.modules[0].knobs.push({ id: 'y', label: 'Ghost', node: 'nope', param: 'cutoff' })
    const result = parseOk(JSON.stringify(raw))
    expect(result.project.modules[0]!.inputs).toHaveLength(1)
    expect(result.project.modules[0]!.knobs).toHaveLength(0)
  })

  it('loads nested modules regardless of the order they are listed in', () => {
    const inner = grouped()
    const track = inner.tracks[0] as InstrumentTrack
    const use = track.patch.nodes.find((node) => node.type === 'module')!
    const nested = groupNodesAsModule(inner, { trackId: track.id }, [use.id], 'Outer')
    expect(nested.modules).toHaveLength(2)

    const raw = JSON.parse(serializeProject(nested))
    raw.project.modules.reverse() // the outer module now comes before the one it uses
    const result = parseOk(JSON.stringify(raw))
    expect(result.project.modules.map((module) => module.name).sort()).toEqual(['Core', 'Outer'])
    expect(result.warnings).toEqual([])
  })

  it('drops a module that contains itself instead of looping', () => {
    const raw = JSON.parse(serializeProject(grouped()))
    const module = raw.project.modules[0]
    module.patch.nodes.push({ id: 'self', type: 'module', moduleId: module.id, x: 0, y: 0, params: {} })
    const result = parseOk(JSON.stringify(raw))
    expect(result.project.modules).toEqual([])
    expect(result.warnings.join(' ')).toMatch(/contain themselves/)
  })
})

describe('note graphs in files', () => {
  /** The bass track with a split, an effect on one branch, and notes from the lead mixed back in. */
  const withGraph = () => {
    const demo = createDemoProject()
    const [bass, lead] = demo.tracks as InstrumentTrack[]
    const graph = noteGraphFrom(
      [
        { id: 'c', type: 'clipNotes' },
        { id: 's', type: 'rangeSplit', params: { lowPitch: 55 } },
        { id: 'a', type: 'arpeggiator', params: { rate: 2 } },
        { id: 't', type: 'trackNotes', trackId: lead!.id, params: { tap: 1 } },
        { id: 'o', type: 'noteOut' },
      ],
      ['c.out>s.in', 's.inside>a.in', 'a.out>o.in', 's.outside>o.in', 't.out>o.in'],
    )
    return { project: editPatchAt(demo, { trackId: bass!.id, graph: 'notes' }, () => graph), bass: bass!, lead: lead! }
  }
  const graphOf = (project: Project, index = 0) => (project.tracks[index] as InstrumentTrack).noteGraph

  it('every track starts with the clip notes wired to the instrument', () => {
    const graph = graphOf(createDemoProject())
    expect(graph.nodes.map((node) => node.type)).toEqual(['clipNotes', 'noteOut'])
    expect(graph.connections).toHaveLength(1)
  })

  it('round-trips a graph with splits, merges and a track reference exactly', () => {
    const { project } = withGraph()
    const result = parseOk(serializeProject(project, 2))
    expect(result.project).toEqual(project)
    expect(result.warnings).toEqual([])
  })

  it('files without a note graph load with the default one', () => {
    const raw = JSON.parse(serializeProject(createDemoProject()))
    for (const track of raw.project.tracks) delete track.noteGraph
    const result = parseOk(JSON.stringify(raw))
    expect(graphOf(result.project).nodes.map((node) => node.type)).toEqual(['clipNotes', 'noteOut'])
    expect(result.warnings).toEqual([])
  })

  it('drops an input that points at a missing track, or at its own track', () => {
    const { project, bass } = withGraph()
    const raw = JSON.parse(serializeProject(project))
    raw.project.tracks[0].noteGraph.nodes.find((n: { id: string }) => n.id === 't').trackId = 'ghost'
    let result = parseOk(JSON.stringify(raw))
    expect(graphOf(result.project).nodes.find((n) => n.id === 't')!.trackId).toBeUndefined()
    expect(result.warnings.join(' ')).toMatch(/missing track or at itself/)

    raw.project.tracks[0].noteGraph.nodes.find((n: { id: string }) => n.id === 't').trackId = bass.id
    result = parseOk(JSON.stringify(raw))
    expect(graphOf(result.project).nodes.find((n) => n.id === 't')!.trackId).toBeUndefined()
  })

  it('drops an input that would make two tracks feed each other', () => {
    const { project, bass, lead } = withGraph()
    const raw = JSON.parse(serializeProject(project))
    raw.project.tracks[1].noteGraph.nodes.push({ id: 'back', type: 'trackNotes', x: 0, y: 0, params: { tap: 0 }, trackId: bass.id })
    const result = parseOk(JSON.stringify(raw))
    const taps = [0, 1].flatMap((index) => graphOf(result.project, index).nodes.filter((n) => n.trackId !== undefined))
    expect(taps).toHaveLength(1) // one of the two was dropped
    expect(result.warnings.join(' ')).toMatch(/feed each other/)
    expect([bass.id, lead.id]).toContain(taps[0]!.trackId)
  })

  it('keeps sound nodes out of a note graph and note nodes out of a patch', () => {
    const raw = JSON.parse(serializeProject(createDemoProject()))
    raw.project.tracks[0].noteGraph.nodes.push({ id: 'osc', type: 'oscillator', x: 0, y: 0, params: {} })
    raw.project.tracks[0].patch.nodes.push({ id: 'arp', type: 'arpeggiator', x: 0, y: 0, params: {} })
    const result = parseOk(JSON.stringify(raw))
    expect(graphOf(result.project).nodes.some((n) => n.type === 'oscillator')).toBe(false)
    expect((result.project.tracks[0] as InstrumentTrack).patch.nodes.some((n) => n.type === 'arpeggiator')).toBe(false)
    expect(result.warnings.join(' ')).toMatch(/sound and notes do not mix/)
  })

  it('drops wires between sound and note ports', () => {
    const { project } = withGraph()
    const raw = JSON.parse(serializeProject(project))
    raw.project.tracks[0].noteGraph.connections.push({ id: 'bad', from: { node: 'c', port: 'out' }, to: { node: 'nowhere', port: 'in' } })
    expect(parseOk(JSON.stringify(raw)).warnings.join(' ')).toMatch(/dropped 1 invalid connection/)
  })

  it('round-trips a module of note nodes, with its ports typed as notes', () => {
    const { project, bass } = withGraph()
    const ids = ['a']
    const grouped = groupNodesAsModule(project, { trackId: bass.id, graph: 'notes' }, ids, 'Arp box')
    expect(grouped.modules).toHaveLength(1)
    const result = parseOk(serializeProject(grouped))
    expect(result.project).toEqual(grouped)
    expect(result.warnings).toEqual([])
    const use = graphOf(result.project).nodes.find((n) => n.type === 'module')!
    expect(describeNode(use, result.project.modules)!.inputs[0]!.kind).toBe('notes')
  })
})

describe('mixer settings in files', () => {
  const track = (extra: Record<string, unknown>) => ({ kind: 'instrument', id: 't', name: 'T', volume: 0.5, clips: [], ...extra })
  const load = (tracks: unknown[], master?: unknown) => parseOk(envelope(project({ tracks, ...(master === undefined ? {} : { master }) }))).project

  it('load with the defaults from files that have none: centre, unmuted, unsoloed, master volume 1', () => {
    const loaded = load([track({})])
    expect(loaded.tracks[0]).not.toHaveProperty('pan')
    expect(loaded.tracks[0]).not.toHaveProperty('muted')
    expect(loaded.tracks[0]).not.toHaveProperty('soloed')
    expect(loaded.master).not.toHaveProperty('volume')
  })

  it('survive a round trip', () => {
    const base = createDemoProject()
    const mixed = {
      ...base,
      master: { ...base.master, volume: 0.25 },
      tracks: base.tracks.map((t, index) => (index === 0 ? { ...t, pan: -0.5, muted: true, soloed: true } : t)),
    }
    expect(parseOk(serializeProject(mixed)).project).toEqual(mixed)
  })

  it('read garbage as the defaults, and clamp what is out of range', () => {
    const loaded = load(
      [track({ pan: 'left', muted: 'yes', soloed: 1 }), track({ id: 'u', pan: 9, muted: true }), track({ id: 'v', pan: null, soloed: true })],
      { volume: 'loud' },
    )
    expect(loaded.tracks[0]).not.toHaveProperty('pan')
    expect(loaded.tracks[0]).not.toHaveProperty('muted')
    expect(loaded.tracks[0]).not.toHaveProperty('soloed')
    expect(loaded.tracks[1]).toMatchObject({ pan: 1, muted: true })
    expect(loaded.tracks[2]).toMatchObject({ soloed: true })
    expect(loaded.tracks[2]).not.toHaveProperty('pan')
    expect(loaded.master).not.toHaveProperty('volume')
    expect(load([], { volume: 5 }).master).not.toHaveProperty('volume')
    expect(load([], { volume: -5 }).master.volume).toBe(0)
  })

  it('apply to audio and return tracks as well', () => {
    const loaded = load([track({ kind: 'audio', pan: 0.2, muted: true }), track({ kind: 'return', id: 'r', pan: -0.2, soloed: true })])
    expect(loaded.tracks[0]).toMatchObject({ kind: 'audio', pan: 0.2, muted: true })
    expect(loaded.tracks[1]).toMatchObject({ kind: 'return', pan: -0.2, soloed: true })
  })
})

describe('the front panel in files', () => {
  const instrument = (nodes: unknown[]) =>
    project({ tracks: [{ id: 't', name: 'T', patch: { nodes: [{ id: 'o', type: 'oscillator', x: 0, y: 0, params: {} }, ...nodes], connections: [] }, clips: [] }] })
  const nodesOf = (loaded: { tracks: readonly unknown[] }) => (loaded.tracks[0] as InstrumentTrack).patch.nodes

  it('keeps where a control sits: hidden, size and order', () => {
    const { project: loaded, warnings } = parseOk(envelope(instrument([
      { id: 'k', type: 'control', x: 0, y: 0, params: {}, panel: { show: false, size: 'L', order: 3 } },
    ])))
    expect(warnings).toEqual([])
    expect(nodesOf(loaded).find((n) => n.id === 'k')!.panel).toEqual({ show: false, size: 'L', order: 3 })
  })

  it('drops what is malformed, and the field where nothing is left; show can only be false', () => {
    const { project: loaded } = parseOk(envelope(instrument([
      { id: 'a', type: 'control', x: 0, y: 0, params: {}, panel: { show: true, size: 'XL', order: -1 } },
      { id: 'b', type: 'control', x: 0, y: 0, params: {}, panel: { order: 1.5 } },
      { id: 'c', type: 'control', x: 0, y: 0, params: {}, panel: 'nope' },
      { id: 'd', type: 'xyPad', x: 0, y: 0, params: {}, panel: { size: 'M', order: 2 } },
    ])))
    const get = (id: string) => nodesOf(loaded).find((n) => n.id === id)!
    expect(['a', 'b', 'c'].map((id) => 'panel' in get(id))).toEqual([false, false, false])
    expect(get('d').panel).toEqual({ size: 'M', order: 2 })
  })

  it('keeps no panel on a node that is not a control', () => {
    const { project: loaded } = parseOk(envelope(instrument([])))
    const raw = JSON.parse(envelope(instrument([])))
    raw.project.tracks[0].patch.nodes[0].panel = { size: 'L' }
    expect('panel' in nodesOf(parseOk(JSON.stringify(raw)).project)[0]!).toBe(false)
    expect(loaded).toBeDefined()
  })

  it('ignores the front panel older versions stored on the patch, without a warning', () => {
    const raw = JSON.parse(envelope(instrument([])))
    raw.project.tracks[0].patch.panel = [{ id: 'c', kind: 'knob', bind: { node: 'o', param: 'frequency' } }]
    const result = parseOk(JSON.stringify(raw))
    expect(result.warnings).toEqual([])
    expect('panel' in (result.project.tracks[0] as InstrumentTrack).patch).toBe(false)
  })

  it('round-trips a panel of control nodes', () => {
    const base = createDemoProject()
    const bass = base.tracks[0] as InstrumentTrack
    const built = editPatchAt(base, { trackId: bass.id }, (patch) => {
      const a = { ...createNode('control', 0, 400), id: 'ka', panel: { order: 1 } }
      const b = { ...createNode('xyPad', 0, 500), id: 'kb', panel: { size: 'L' as const, order: 0 }, unit: 'Hz' }
      return [a, b].reduce(addNode, patch)
    })
    const result = parseOk(serializeProject(built))
    expect(result.warnings).toEqual([])
    expect(result.project).toEqual(built)
  })
})

describe('scene names', () => {
  const loaded = (sceneNames: unknown, sceneCount = 3) => parseOk(envelope(project({ sceneCount, sceneNames }))).project

  it('survive a save and a load, and a project without any has none (older files load as before)', () => {
    const named = { ...createDemoProject(), sceneNames: ['Intro', '', 'Drop', 'Outro'] }
    expect(parseOk(serializeProject(named)).project.sceneNames).toEqual(['Intro', '', 'Drop', 'Outro'])
    expect(parseOk(serializeProject(createDemoProject())).project).not.toHaveProperty('sceneNames')
  })

  it('are trimmed and cut to the length of a label, and only one is kept for each scene', () => {
    expect(loaded(['  Intro  ', 'a'.repeat(60), 'Drop', 'one too many'])?.sceneNames).toEqual(['Intro', 'a'.repeat(24), 'Drop'])
  })

  it('are dropped when they are not text, and a list of nothing is no list', () => {
    expect(loaded(['A', 7, null, { x: 1 }])?.sceneNames).toEqual(['A', '', '', ''].slice(0, 3))
    expect(loaded(['', '  ', 3])).not.toHaveProperty('sceneNames')
    expect(loaded('Intro')).not.toHaveProperty('sceneNames')
    expect(loaded({ 0: 'Intro' })).not.toHaveProperty('sceneNames')
    expect(loaded(undefined)).not.toHaveProperty('sceneNames')
  })
})

