import { audioSourceTracks, sendableReturns, tappableTracks } from '@core'
import { useProjectStore } from '@state'
import styles from './Patcher.module.css'

interface TrackPickerProps {
  /** `notes`: another instrument track to take notes from. `return`: a return track to send to. `audio`: another track to take sound from. */
  pick: 'notes' | 'return' | 'audio'
  /** The track whose graph this is: it cannot point at itself, or at a track that points back at it. */
  ownerTrackId: string
  trackId: string | undefined
  onChange(trackId: string | null): void
}

const TEXT = {
  notes: { label: 'Take notes from track', none: '(no other instrument track)' },
  return: { label: 'Send to return track', none: '(no return track: add one with +)' },
  audio: { label: 'Take audio from track', none: '(no other track)' },
} as const

/** Chooses which other track a Track notes node takes its notes from, which return track a Send sends to, or which track a Track audio node takes sound from. */
export const TrackPicker = ({ pick, ownerTrackId, trackId, onChange }: TrackPickerProps) => {
  const project = useProjectStore((state) => state.project)
  const choices = pick === 'notes' ? tappableTracks(project, ownerTrackId) : pick === 'return' ? sendableReturns(project, ownerTrackId) : audioSourceTracks(project, ownerTrackId)
  const current = trackId ? project.tracks.find((track) => track.id === trackId) : undefined

  return (
    <div className={styles.trackPicker}>
      <select value={trackId ?? ''} aria-label={TEXT[pick].label} onChange={(event) => onChange(event.target.value || null)}>
        <option value="">{choices.length === 0 ? TEXT[pick].none : '(choose a track)'}</option>
        {/* Keep showing the current choice even if it has become unavailable. */}
        {current && !choices.some((choice) => choice.id === current.id) && <option value={current.id}>{current.name}</option>}
        {choices.map((track) => (
          <option key={track.id} value={track.id}>
            {track.name}
          </option>
        ))}
      </select>
    </div>
  )
}
